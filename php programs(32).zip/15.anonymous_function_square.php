<?php
$square = function ($num) {
    return $num * $num;
};

echo $square(4) . "<br>";
