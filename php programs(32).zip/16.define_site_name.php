<?php
define('SITE_NAME', 'MyWebsite');
echo SITE_NAME . "<br>";
