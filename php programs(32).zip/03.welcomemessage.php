<?php

function welcomeMessage()
{
    echo "Welcome to PHP programming!!";
}

welcomeMessage();
