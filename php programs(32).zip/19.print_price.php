<?php
$price = 100;
printf("The price is %d<br>", $price);
