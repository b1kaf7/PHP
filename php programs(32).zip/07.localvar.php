<?php
function printVar()
{
    $var = "Hello, World!";
    echo $var;
}

printVar();
