<?php
$month = "Feb";

switch ($month) {
    case "Jan":
        echo "This is first month of year";
        break;
    case "Feb":
        echo "This is second month of year.";
        break;
    case "March":
        echo "This is third month of year";
        break;
    case "April":
        echo "This is fourth month of year.";
        break;
    case "May":
        echo "This is fifth month of year";
        break;
    case "June":
        echo "This is sixth month of year.";
        break;
    case "July":
        echo "This is seventh month of year";
        break;
    case "Aug":
        echo "This is eighth month of year.";
        break;
    case "Sept":
        echo "This is ninth month of year";
        break;
    case "Oct":
        echo "This is tenth month of year.";
        break;
    case "Nov":
        echo "This is eleventh month of year";
        break;
    case "Dec":
        echo "This is last month of year.";
        break;
    default:
        echo "Invalid month";
}
