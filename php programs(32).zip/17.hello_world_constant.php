<?php
const HELLO_WORLD = 'Hello, World!';
echo HELLO_WORLD;
