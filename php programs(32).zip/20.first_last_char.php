<?php
$str = "Hello";
echo "First character: " . $str[0] . ", Last character: " . $str[strlen($str) - 1] . "<br>";
