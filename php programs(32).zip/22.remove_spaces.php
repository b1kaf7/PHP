<?php
$str = "  Hello World!  ";
echo trim($str) . "<br>";
echo ltrim($str) . "<br>";
echo rtrim($str) . "<br>";
