<?php
echo "Welcome to PHP!<br>";
print "Welcome to PHP!<br>";
printf("Welcome to PHP!<br>");
