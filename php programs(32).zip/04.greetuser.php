<?php

function greetuser($name = "Guest")
{
    echo "Hello $name";
}
greetuser("Sweetie!");
// greetuser(); 
