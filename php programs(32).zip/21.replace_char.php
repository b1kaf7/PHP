<?php
$str = "WORLD";
$str[2] = 'X';
echo $str . "<br>";
