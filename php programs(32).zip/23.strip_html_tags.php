<?php
$str = "<h1>Welcome</h1> to <b>PHP</b>!";
echo strip_tags($str) . "<br>";
