<?php
function getName()
{
    $name = "rohan";
    return $name;
}

echo getName();
