<?php
for ($n = 1; $n <= 10; $n++) {
    echo ("$n<br>");
}
