<?php
$fruit = ['apple', 'banana', 'mango', 'guava'];
$fruit[1] = 'strawberry';

foreach ($fruit as $item) {
    echo $item . "<br>";
}
