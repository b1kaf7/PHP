<?php
$countries = ["UK", "USA", "Canada", "Australia", "India"];
foreach ($countries as $country) {
    echo $country . "<br>";
}
