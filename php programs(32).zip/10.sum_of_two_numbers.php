<?php
function sum($a, $b)
{
    return $a + $b;
}
echo sum(2, 4);
